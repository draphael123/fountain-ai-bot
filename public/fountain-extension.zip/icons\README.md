# Extension Icons

Replace these placeholder files with proper PNG icons:

- `icon16.png` - 16x16 pixels
- `icon48.png` - 48x48 pixels  
- `icon128.png` - 128x128 pixels

You can generate these from the SVG or create custom icons.

Recommended design:
- Blue background (#3B82F6)
- White document icon
- Rounded corners

